package com.daniel.hellohuman;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class helloHumanController {
    @RequestMapping("")
    public String hello() {
            return "Hello Human";
    }
    @RequestMapping("/")
    public String index(@RequestParam(value="name", required=false)  String searchQuery) {
    	if (searchQuery == null) {
    		return ("Hello Human");
    	}
            return ("Hello " + searchQuery);
    }
    

}
